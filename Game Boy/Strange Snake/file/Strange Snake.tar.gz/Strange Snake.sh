#!/bin/bash

retroarch -L mgba_libretro.so Strange\ Snake.gb