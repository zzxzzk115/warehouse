#!/bin/bash

retroarch -L mgba_libretro.so -S dot.glslp Strange\ Snake.gb